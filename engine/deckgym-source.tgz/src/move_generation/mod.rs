mod attacks;
mod move_generation_abilities;
mod move_generation_trainer;

use crate::actions::{abilities::AbilityMechanic, Action, SimpleAction};
use crate::effects::TurnEffect;
use crate::hooks::{can_evolve_into, can_retreat, contains_energy, get_retreat_cost};
use crate::models::Card;
use crate::stadiums::{
    can_use_abandoned_station, can_use_arcade, can_use_area_zero, can_use_fragrant_forest,
    can_use_kids_room, can_use_mesagoza, can_use_rainbow_cave,
};
use crate::state::State;

use attacks::generate_attack_actions;
use move_generation_abilities::generate_ability_actions;
pub use move_generation_trainer::{
    generate_possible_trainer_actions, trainer_move_generation_implementation,
};

/// Generates a list of possible moves for the current player.
///
/// # Arguments
/// * `state` - The current state of the game.
///
/// # Returns
/// * A tuple containing the current player and a list of possible actions
pub fn generate_possible_actions(state: &State) -> (usize, Vec<Action>) {
    let mut watch = crate::perf_watch::watch("generate_possible_actions", state, None);
    let generated = generate_possible_actions_unwatched(state);
    watch.branches(generated.1.len());
    generated
}

fn generate_possible_actions_unwatched(state: &State) -> (usize, Vec<Action>) {
    let in_initial_setup_phase = state.turn_count == 0;
    if in_initial_setup_phase {
        let possible_actions = generate_initial_setup_actions(state)
            .iter()
            .map(|action| Action {
                actor: state.current_player,
                action: action.clone(),
                is_stack: false,
            })
            .collect();
        return (state.current_player, possible_actions);
    }

    // If there are moves in the generation stack, short-circuit to that
    if let Some((actor, possible_actions)) = state.move_generation_stack.last() {
        let actions = possible_actions
            .iter()
            .map(|action| Action {
                actor: *actor,
                action: action.clone(),
                is_stack: true,
            })
            .collect();
        return (*actor, actions);
    }

    if state.end_turn_pending {
        return (
            state.current_player,
            vec![Action {
                actor: state.current_player,
                action: SimpleAction::EndTurn,
                is_stack: false,
            }],
        );
    }

    // Free play actions. User can always end turn.
    let current_player = state.current_player;
    // An empty Active Spot always queues a promotion or ends the game, so free play should never
    // see one. Reaching here without an Active means a caller is generating moves for a finished
    // game (or a removal path forgot to call `trigger_promotion_or_declare_winner`).
    debug_assert!(
        state.in_play_pokemon[current_player][0].is_some(),
        "Free-play move generation without an Active Pokemon (winner: {:?})",
        state.winner
    );
    let mut actions = vec![SimpleAction::EndTurn];

    // Hand actions (Play Support Cards, Trainer, or Place Pokemons in mat)
    let hand_actions = generate_hand_actions(state);
    actions.extend(hand_actions);

    // Maybe attach energy to in play cards
    if let Some(energy) = state.energy_zone[current_player].current {
        state.in_play_pokemon[current_player]
            .iter()
            .enumerate()
            .for_each(|(i, x)| {
                if x.is_some() {
                    if !state.can_attach_energy_from_zone(i) {
                        return;
                    }
                    actions.push(SimpleAction::Attach {
                        attachments: vec![(1, energy, i)],
                        is_turn_energy: true,
                    });
                }
            })
    }

    // Maybe retreat pokemon
    if let Some(card) = &state.in_play_pokemon[current_player][0] {
        if can_retreat(state)
            && contains_energy(
                card,
                &get_retreat_cost(state, current_player, card, true),
                state,
                current_player,
            )
        {
            state
                .enumerate_bench_pokemon(current_player)
                .for_each(|(i, _)| {
                    actions.push(SimpleAction::Retreat(i));
                });
        }
    }

    // Maybe discard fossils (fossils can be discarded at any time during your turn)
    generate_discard_fossil_actions(state, &mut actions);

    // Maybe attack (only starting on turn 2)
    let attack_actions = generate_attack_actions(state);
    actions.extend(attack_actions);

    // Add actions given by abilities
    let ability_actions = generate_ability_actions(state);
    actions.extend(ability_actions);

    // Add actions given by active stadium (activated stadiums like Mesagoza, Fragrant Forest, Area Zero)
    if can_use_mesagoza(state, current_player)
        || can_use_fragrant_forest(state, current_player)
        || can_use_area_zero(state, current_player)
        || can_use_kids_room(state, current_player)
        || can_use_rainbow_cave(state, current_player)
        || can_use_arcade(state, current_player)
        || can_use_abandoned_station(state, current_player)
    {
        actions.push(SimpleAction::UseStadium);
    }

    // Turn timer: the app ends a turn when its timer runs out, which also bounds actions
    // that may repeat without limit. Two Dusknoir can pass damage back and forth with Shadow
    // Void ("as often as you like") forever, so a player that keeps choosing it never ends
    // the turn. After MAX_ACTIONS_PER_TURN actions only actions that end the turn remain.
    if state.actions_this_turn >= MAX_ACTIONS_PER_TURN {
        actions.retain(|action| matches!(action, SimpleAction::EndTurn | SimpleAction::Attack(_)));
    }

    let possible_actions = actions
        .iter()
        .map(|action| Action {
            actor: current_player,
            action: action.clone(),
            is_stack: false,
        })
        .collect();
    (current_player, possible_actions)
}

/// Actions a turn may take (counting pending choices) before only ending it is allowed. A
/// real turn takes a few dozen at most; this stands in for the app's turn timer.
pub const MAX_ACTIONS_PER_TURN: u16 = 100;

fn generate_initial_setup_actions(state: &State) -> Vec<SimpleAction> {
    let current_player = state.current_player;
    let hand_actions = generate_hand_actions(state);
    if state.in_play_pokemon[current_player][0].is_none() {
        let place_active_actions: Vec<SimpleAction> = hand_actions
            .iter()
            .filter(|x| matches!(x, SimpleAction::Place(_, 0)))
            .cloned()
            .collect();
        place_active_actions
    } else {
        let mut actions = Vec::new();
        let place_bench_actions: Vec<SimpleAction> = hand_actions
            .iter()
            .filter(|x| {
                if let SimpleAction::Place(_, position) = x {
                    *position != 0
                } else {
                    false
                }
            })
            .cloned()
            .collect();
        actions.extend(place_bench_actions);
        actions.push(SimpleAction::EndTurn);
        actions
    }
}

fn generate_hand_actions(state: &State) -> Vec<SimpleAction> {
    let current_player = state.current_player;
    let mut actions = Vec::new();

    get_current_hand(state)
        .iter()
        .for_each(|hand_card| match hand_card {
            Card::Pokemon(pokemon_card) => {
                // Basic pokemons can be placed in empty Active or Bench slots
                if pokemon_card.stage == 0 {
                    state.in_play_pokemon[current_player]
                        .iter()
                        .enumerate()
                        .for_each(|(i, x)| {
                            if x.is_none() {
                                actions.push(SimpleAction::Place(hand_card.clone(), i));
                            }
                        });
                } else {
                    // Evolutions can only be played if previous stage
                    // is there, and wasn't played this turn, and isn't the first 2 turns.
                    // Exception: Eevee with Boosted Evolution ability can evolve on first turn
                    // or turn it was played, if it's in the active spot (that Eevee only).

                    // For each non-zero stage pokemon in hand, check if it can evolve
                    // from any pokemon in play (using can_evolve_into which handles special abilities)
                    state
                        .enumerate_in_play_pokemon(current_player)
                        .for_each(|(i, pokemon)| {
                            // Check if this pokemon has Boosted Evolution and is in active spot
                            let can_bypass_timing = i == 0
                                && matches!(
                                    pokemon.ability_mechanic(),
                                    Some(AbilityMechanic::CanEvolveOnFirstTurnIfActive)
                                );

                            if state.is_users_first_turn() && !can_bypass_timing {
                                return;
                            }

                            if (!pokemon.played_this_turn || can_bypass_timing)
                                && can_evolve_into(hand_card, pokemon)
                                && can_evolve_at_position(state, current_player, i)
                            {
                                actions.push(SimpleAction::Evolve {
                                    evolution: hand_card.clone(),
                                    in_play_idx: i,
                                    from_deck: false, // Normal evolution from hand
                                });
                            }
                        });
                }
            }
            Card::Trainer(trainer_card) => {
                let trainer_actions = generate_possible_trainer_actions(state, trainer_card)
                    .expect("Trainer card not implemented");
                actions.extend(trainer_actions);
            }
        });
    actions
}

fn get_current_hand(state: &State) -> &Vec<Card> {
    &state.hands[state.current_player]
}

fn generate_discard_fossil_actions(state: &State, actions: &mut Vec<SimpleAction>) {
    let current_player = state.current_player;

    // Check all in-play pokemon to see if any are fossils
    state
        .enumerate_in_play_pokemon(current_player)
        .for_each(|(i, pokemon)| {
            if pokemon.is_fossil() {
                actions.push(SimpleAction::DiscardFossil { in_play_idx: i });
            }
        });
}

/// Checks if playing a Pokémon from hand to evolve the Pokémon at the given position is allowed,
/// considering ability restrictions. Also used for Rare Candy, which evolves from hand too.
pub(crate) fn can_evolve_at_position(state: &State, player: usize, position: usize) -> bool {
    // Malamar's Evolution Jammer: "they can't play any Pokémon from their hand to evolve their
    // Pokémon."
    if state.get_current_turn_effects().iter().any(|effect| {
        matches!(effect, TurnEffect::NoEvolutionFromHand { player: jammed } if *jammed == player)
    }) {
        return false;
    }
    // Aerodactyl Ex's Primeval Law blocks evolution of opponent's active Pokemon
    if position == 0 && has_opponent_aerodactyl_ex_primeval_law(state, player) {
        return false;
    }
    true
}

fn has_opponent_aerodactyl_ex_primeval_law(state: &State, player: usize) -> bool {
    let opponent = (player + 1) % 2;

    // Check if opponent has any Aerodactyl Ex with Primeval Law ability in play
    state
        .enumerate_in_play_pokemon(opponent)
        .any(|(_, pokemon)| {
            matches!(
                pokemon.ability_mechanic(),
                Some(AbilityMechanic::PreventOpponentActiveEvolution)
            )
        })
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{card_ids::CardId, database::get_card_by_enum, hooks::to_playable_card};

    #[test]
    fn test_aerodactyl_evolve_action_appears_with_fossil_in_mat() {
        // Setup: Player has Old Amber in active spot and Aerodactyl in hand
        let mut state = State::default();
        state.turn_count = 3; // After first 2 turns (evolution allowed)

        // Place Old Amber fossil in active spot
        let old_amber = get_card_by_enum(CardId::A1218OldAmber);
        let played_old_amber = to_playable_card(&old_amber, false);
        state.in_play_pokemon[0][0] = Some(played_old_amber.clone());

        // Add Aerodactyl to hand
        let aerodactyl = get_card_by_enum(CardId::A1210Aerodactyl);
        state.hands[0].push(aerodactyl.clone());

        // Debug output
        println!("Old Amber name: {}", played_old_amber.get_name());
        println!(
            "Old Amber played_this_turn: {}",
            played_old_amber.played_this_turn
        );
        if let Card::Pokemon(poke) = &aerodactyl {
            println!("Aerodactyl evolves_from: {:?}", poke.evolves_from);
        }
        println!(
            "can_evolve_into result: {}",
            can_evolve_into(&aerodactyl, &played_old_amber)
        );

        // Generate actions
        let hand_actions = generate_hand_actions(&state);

        println!("Generated {} hand actions", hand_actions.len());
        for action in &hand_actions {
            println!("Action: {}", action);
        }

        // Check that an Evolve action is present
        let has_evolve_action = hand_actions.iter().any(|action| {
            matches!(
                action,
                SimpleAction::Evolve { evolution, in_play_idx: 0, .. } if evolution.get_id() == aerodactyl.get_id()
            )
        });

        assert!(
            has_evolve_action,
            "Should be able to evolve Old Amber into Aerodactyl"
        );
    }

    #[test]
    fn test_aerodactyl_ex_evolve_action_appears_with_fossil_in_mat() {
        // Setup: Player has Old Amber in bench and Aerodactyl ex in hand
        let mut state = State::default();
        state.turn_count = 3; // After first 2 turns (evolution allowed)

        // Place Old Amber fossil in bench slot 1
        let old_amber = get_card_by_enum(CardId::A1218OldAmber);
        let played_old_amber = to_playable_card(&old_amber, false);
        state.in_play_pokemon[0][1] = Some(played_old_amber);

        // Add Aerodactyl ex to hand
        let aerodactyl_ex = get_card_by_enum(CardId::A1a046AerodactylEx);
        state.hands[0].push(aerodactyl_ex.clone());

        // Generate actions
        let hand_actions = generate_hand_actions(&state);

        // Check that an Evolve action is present for bench position
        let has_evolve_action = hand_actions.iter().any(|action| {
            matches!(
                action,
                SimpleAction::Evolve { evolution, in_play_idx: 1, .. } if evolution.get_id() == aerodactyl_ex.get_id()
            )
        });

        assert!(
            has_evolve_action,
            "Should be able to evolve Old Amber into Aerodactyl ex"
        );
    }

    #[test]
    fn test_aerodactyl_ex_blocks_opponent_active_evolution() {
        // Setup: Player 0 has Aerodactyl ex in play, Player 1 has Bulbasaur and Ivysaur in hand
        let mut state = State::default();
        state.turn_count = 3; // After first 2 turns
        state.current_player = 1; // Player 1's turn

        // Place Aerodactyl ex for player 0
        let aerodactyl_ex = get_card_by_enum(CardId::A1a046AerodactylEx);
        let played_aerodactyl = to_playable_card(&aerodactyl_ex, false);
        state.in_play_pokemon[0][0] = Some(played_aerodactyl);

        // Place Bulbasaur in player 1's active spot
        let bulbasaur = get_card_by_enum(CardId::A1001Bulbasaur);
        let played_bulbasaur = to_playable_card(&bulbasaur, false);
        state.in_play_pokemon[1][0] = Some(played_bulbasaur);

        // Add Ivysaur to player 1's hand
        let ivysaur = get_card_by_enum(CardId::A1002Ivysaur);
        state.hands[1].push(ivysaur.clone());

        // Generate actions for player 1
        let hand_actions = generate_hand_actions(&state);

        // Check that NO Evolve action is present for active position
        let has_active_evolve = hand_actions.iter().any(|action| {
            matches!(
                action,
                SimpleAction::Evolve { evolution, in_play_idx: 0, .. } if evolution.get_id() == ivysaur.get_id()
            )
        });

        assert!(
            !has_active_evolve,
            "Aerodactyl ex's Primeval Law should block active Pokemon evolution"
        );
    }

    #[test]
    fn test_aerodactyl_ex_does_not_block_bench_evolution() {
        // Setup: Player 0 has Aerodactyl ex, Player 1 has Bulbasaur on bench
        let mut state = State::default();
        state.turn_count = 3; // After first 2 turns
        state.current_player = 1;

        // Place Aerodactyl ex for player 0
        let aerodactyl_ex = get_card_by_enum(CardId::A1a046AerodactylEx);
        let played_aerodactyl = to_playable_card(&aerodactyl_ex, false);
        state.in_play_pokemon[0][0] = Some(played_aerodactyl);

        // Place a different pokemon in active for player 1
        let charmander = get_card_by_enum(CardId::A1033Charmander);
        state.in_play_pokemon[1][0] = Some(to_playable_card(&charmander, false));

        // Place Bulbasaur on player 1's bench
        let bulbasaur = get_card_by_enum(CardId::A1001Bulbasaur);
        let played_bulbasaur = to_playable_card(&bulbasaur, false);
        state.in_play_pokemon[1][1] = Some(played_bulbasaur);

        // Add Ivysaur to player 1's hand
        let ivysaur = get_card_by_enum(CardId::A1002Ivysaur);
        state.hands[1].push(ivysaur.clone());

        // Generate actions
        let hand_actions = generate_hand_actions(&state);

        // Check that Evolve action IS present for bench position
        let has_bench_evolve = hand_actions.iter().any(|action| {
            matches!(
                action,
                SimpleAction::Evolve { evolution, in_play_idx: 1, .. } if evolution.get_id() == ivysaur.get_id()
            )
        });

        assert!(
            has_bench_evolve,
            "Aerodactyl ex's Primeval Law should NOT block bench Pokemon evolution"
        );
    }
}
