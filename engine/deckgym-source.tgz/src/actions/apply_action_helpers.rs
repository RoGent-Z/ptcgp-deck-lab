use std::collections::HashMap;

use log::debug;
use rand::rngs::StdRng;

use crate::{
    actions::{
        abilities::AbilityMechanic, ability_mechanic_from_effect, shared_mutations, SimpleAction,
    },
    card_ids::CardId,
    effects::{CardEffect, TurnEffect},
    hooks::{
        get_attack_hit_back_weakness_extra, get_counterattack_damage,
        get_delayed_counterattack_damage, modify_damage, on_attack_knockout, on_end_turn,
        on_knockout, should_poison_attacker, DamageModifierContext,
    },
    models::{Card, PlayedCard, StatusCondition, TrainerType},
    state::GameOutcome,
    tools::has_tool,
    State,
};

use super::Action;

pub(crate) type Probabilities = Vec<f64>;

// Mutations should be deterministic. They take StdRng because we simplify some states spaces
//  like "shuffling a deck" (which would otherwise yield a huge state space) to a single
//  mutation/state ("shuffled deck"). Bots should not use deck order information when forecasting.
pub(crate) type FnMutation = Box<dyn Fn(&mut StdRng, &mut State, &Action)>;
pub(crate) type Mutation = Box<dyn FnOnce(&mut StdRng, &mut State, &Action)>;
pub(crate) type Mutations = Vec<Mutation>;

#[derive(Clone)]
struct CheckupTargets {
    /// Every Pokemon carrying at least one Checkup-relevant Special Condition, in the order the
    /// in-app Tips panel prescribes: "If both players' Pokemon are affected by Special
    /// Conditions, the player whose turn just ended checks their Special Conditions first", and
    /// within a side the Active Spot before the Bench. Each Pokemon's own conditions are then
    /// resolved Poisoned -> Burned -> Asleep -> Paralyzed.
    order: Vec<(usize, usize)>,
    sleeps: Vec<(usize, usize)>,
    /// How many coins each entry of `sleeps` flips: 1, or more when an attack replaced the usual
    /// flip (Jigglypuff's Soothing Lullaby).
    sleep_coins: Vec<usize>,
    paralyzed: Vec<(usize, usize)>,
    poisoned: Vec<(usize, usize)>,
    burned: Vec<(usize, usize)>,
}

impl CheckupTargets {
    /// Total coins flipped for Asleep Pokemon.
    fn total_sleep_coins(&self) -> usize {
        self.sleep_coins.iter().sum()
    }
}

/// Advance state to the next turn (i.e. maintain current_player and turn_count)
pub(crate) fn forecast_end_turn(state: &State) -> (Probabilities, Mutations) {
    let in_setup_phase = state.turn_count == 0;
    if in_setup_phase {
        let both_players_initiated =
            state.in_play_pokemon[0][0].is_some() && state.in_play_pokemon[1][0].is_some();
        if !both_players_initiated {
            // Just advance the setup phase to the next player
            return (
                vec![1.0],
                vec![Box::new(|_, state, _| {
                    state.end_turn_pending = false;
                    state.current_player = (state.current_player + 1) % 2;
                })],
            );
        }

        let next_player = (state.current_player + 1) % 2;
        let (start_probs, start_mutations) = start_turn_ability_outcomes(state, next_player, true);

        let mut outcomes: Mutations = Vec::with_capacity(start_mutations.len());
        for start_mutation in start_mutations {
            outcomes.push(Box::new(move |rng, state, action| {
                state.end_turn_pending = false;
                state.current_player = (state.current_player + 1) % 2;

                // Actually start game (no energy generation)
                state.turn_count = 1;
                state.end_turn_maintenance();
                start_mutation(rng, state, action);
                state.queue_draw_action(state.current_player, 1);
            }));
        }

        (start_probs, outcomes)
    } else {
        forecast_pokemon_checkup(state)
    }
}

/// Handle Status Effects
fn forecast_pokemon_checkup(state: &State) -> (Probabilities, Mutations) {
    let next_player = (state.current_player + 1) % 2;
    let mut preview_state = state.clone();
    // Important for these to happen before Pokemon Checkup (Zeraora, Suicune, etc)
    on_end_turn(state.current_player, &mut preview_state);
    let checkup_targets = collect_checkup_targets(&preview_state);

    // Get all binary vectors representing the possible outcomes.
    // These are the "outcome_ids" for sleep and burn coin flips
    // (e.g. outcome [true, false] might represent waking up one pokemon and not healing another's burn).
    let total_coin_flips = checkup_targets.total_sleep_coins() + checkup_targets.burned.len();
    let outcome_ids = generate_boolean_vectors(total_coin_flips);
    let base_probability = 1.0 / outcome_ids.len() as f64;

    let mut probabilities = Vec::with_capacity(outcome_ids.len());
    let mut outcomes: Mutations = Vec::with_capacity(outcome_ids.len());
    for outcome in outcome_ids {
        let mut preview_after_checkup = preview_state.clone();
        apply_pokemon_checkup(&mut preview_after_checkup, &checkup_targets, &outcome);
        let (start_probs, start_mutations) =
            start_turn_ability_outcomes(&preview_after_checkup, next_player, false);
        for (start_prob, start_mutation) in start_probs.into_iter().zip(start_mutations) {
            let outcome = outcome.clone();
            probabilities.push(base_probability * start_prob);
            outcomes.push(Box::new(move |rng, state, action| {
                on_end_turn(action.actor, state);
                let live_checkup_targets = collect_checkup_targets(state);
                apply_pokemon_checkup(state, &live_checkup_targets, &outcome);
                finish_turn_after_checkup(state, rng);

                start_mutation(rng, state, action);

                // Some end-of-turn damage (e.g. Deceptive Needle) defers its knockout check so
                // that abilities triggered in this same window (e.g. Caterpie's Quick Growth,
                // applied by `start_mutation` above) get a chance to evolve — and thus save —
                // the target before it is finally checked for being Knocked Out.
                handle_knockouts(state, (action.actor, 0), false);
            }));
        }
    }
    (probabilities, outcomes)
}

/// Outcomes of abilities that trigger as a turn begins. `from_setup` is true when the turn is
/// starting because setup (turn 0) just ended; setup is not a real turn, so abilities that
/// trigger "at the end of your opponent's turn" (Quick Growth) must not fire.
fn start_turn_ability_outcomes(
    state: &State,
    player: usize,
    from_setup: bool,
) -> (Probabilities, Mutations) {
    let Some(active) = state.maybe_get_active(player) else {
        return (vec![1.0], vec![noop_mutation()]);
    };
    let Some(ability) = active.ability() else {
        return (vec![1.0], vec![noop_mutation()]);
    };
    let Some(mechanic) = ability_mechanic_from_effect(&ability.effect) else {
        return (vec![1.0], vec![noop_mutation()]);
    };

    match mechanic {
        AbilityMechanic::StartTurnRandomPokemonToHand { energy_type } => {
            shared_mutations::pokemon_search_outcomes_by_type_for_player(
                player,
                state,
                false,
                *energy_type,
            )
            .into_branches()
        }
        AbilityMechanic::QuickGrowth if !from_setup => {
            shared_mutations::quick_growth_evolution_outcomes_for_player(player, state)
                .into_branches()
        }
        _ => (vec![1.0], vec![noop_mutation()]),
    }
}

/// Calculate poison damage based on base damage (10) plus +10 for each opponent's Nihilego with More Poison ability
/// Only applies the bonus if the poisoned Pokemon is in the active spot (index 0)
fn get_poison_damage(state: &State, player: usize, in_play_idx: usize) -> u32 {
    use crate::actions::abilities::AbilityMechanic;

    // Usually 10, unless the attack that inflicted the Poison replaced that amount
    // (Toxicroak's Toxic does 20, Toxapex's Severe Poison does 40).
    let base_damage = state.in_play_pokemon[player][in_play_idx]
        .as_ref()
        .map_or(10, |pokemon| pokemon.poison_base_damage());

    // Nihilego's More Poison ability only affects the active Pokemon
    if in_play_idx != 0 {
        return base_damage;
    }

    let opponent = (player + 1) % 2;
    let nihilego_count = state
        .enumerate_in_play_pokemon(opponent)
        .filter(|(_, pokemon)| {
            matches!(
                pokemon.ability_mechanic(),
                Some(AbilityMechanic::IncreasePoisonDamage { amount: 10 })
            )
        })
        .count();

    let total_damage = base_damage + (nihilego_count as u32 * 10);

    if nihilego_count > 0 {
        debug!(
            "Nihilego's More Poison: {} Nihilego in play, poison damage is {}",
            nihilego_count, total_damage
        );
    }

    total_damage
}

fn collect_checkup_targets(state: &State) -> CheckupTargets {
    let mut targets = CheckupTargets {
        order: vec![],
        sleeps: vec![],
        sleep_coins: vec![],
        paralyzed: vec![],
        poisoned: vec![],
        burned: vec![],
    };

    // "the player whose turn just ended checks their Special Conditions first". Checkup runs
    // before `advance_turn`, so the player whose turn just ended is still `current_player`.
    let ending_player = state.current_player;
    for player in [ending_player, (ending_player + 1) % 2] {
        for (i, pokemon) in state.enumerate_in_play_pokemon(player) {
            let mut has_any = false;
            if pokemon.is_poisoned() {
                targets.poisoned.push((player, i));
                debug!("{player}'s Pokemon {i} is poisoned");
                has_any = true;
            }
            if pokemon.is_burned() {
                targets.burned.push((player, i));
                debug!("{player}'s Pokemon {i} is burned");
                has_any = true;
            }
            if pokemon.is_asleep() {
                targets.sleeps.push((player, i));
                targets.sleep_coins.push(pokemon.sleep_checkup_coins());
                has_any = true;
            }
            if pokemon.is_paralyzed() {
                targets.paralyzed.push((player, i));
                has_any = true;
            }
            if has_any {
                targets.order.push((player, i));
            }
        }
    }

    targets
}

fn apply_pokemon_checkup(
    mutated_state: &mut State,
    checkup_targets: &CheckupTargets,
    outcome: &[bool],
) {
    // The sleep coins come first (in `sleeps` order), then one coin per burn
    let num_sleep_coins = checkup_targets.total_sleep_coins();
    debug_assert!(outcome.len() >= num_sleep_coins + checkup_targets.burned.len());

    // In-app Tips, "What is Pokemon Checkup?": each Pokemon's own Special Conditions resolve in
    // the order Poisoned -> Burned -> Asleep -> Paralyzed, and when both players have afflicted
    // Pokemon, "the player whose turn just ended checks their Special Conditions first".
    // `checkup_targets.order` is built in exactly that order, so one pass over it is the whole
    // rule.
    //
    // Knock Outs are deliberately NOT resolved in this loop: "Any Pokemon that has no HP
    // remaining at the end of Pokemon Checkup is Knocked Out", so the single `handle_knockouts`
    // call that closes the end-of-turn sequence (see `forecast_pokemon_checkup`) decides them
    // all at once -- after the healing and Checkup abilities below have had their chance.
    let ending_player = mutated_state.current_player;
    let ending_turn = mutated_state.turn_count;

    for (player, in_play_idx) in checkup_targets.order.iter().copied() {
        if mutated_state.in_play_pokemon[player][in_play_idx].is_none() {
            continue;
        }

        // 1. Poisoned: "take 10 damage during each Pokemon Checkup" (unless an attack replaced
        //    the usual amount).
        if checkup_targets.poisoned.contains(&(player, in_play_idx)) {
            let poison_damage = get_poison_damage(mutated_state, player, in_play_idx);
            handle_damage_only(
                mutated_state,
                (player, in_play_idx), // present it as self-damage
                &[(poison_damage, player, in_play_idx)],
                false,
                DamageModifierContext::default(),
            );
        }

        // 2. Burned: 20 damage, then a coin flip -- on heads the Pokemon recovers.
        if let Some(burn_flip) = checkup_targets
            .burned
            .iter()
            .position(|target| *target == (player, in_play_idx))
        {
            handle_damage_only(
                mutated_state,
                (player, in_play_idx), // present it as self-damage
                &[(20, player, in_play_idx)],
                false,
                DamageModifierContext::default(),
            );
            if outcome[num_sleep_coins + burn_flip] {
                if let Some(pokemon) = mutated_state.in_play_pokemon[player][in_play_idx].as_mut() {
                    pokemon.clear_status_condition(StatusCondition::Burned);
                    debug!("{player}'s Pokemon {in_play_idx} healed from burn");
                }
            }
        }

        // 3. Asleep: a coin flip -- on heads the Pokemon recovers, on tails it stays Asleep.
        //    Soothing Lullaby's Sleep flips 2 coins and recovers only if both are heads.
        if let Some(sleep_idx) = checkup_targets
            .sleeps
            .iter()
            .position(|target| *target == (player, in_play_idx))
        {
            let first_coin: usize = checkup_targets.sleep_coins[..sleep_idx].iter().sum();
            let coins = &outcome[first_coin..first_coin + checkup_targets.sleep_coins[sleep_idx]];
            if coins.iter().all(|heads| *heads) {
                if let Some(pokemon) = mutated_state.in_play_pokemon[player][in_play_idx].as_mut() {
                    pokemon.clear_status_condition(StatusCondition::Asleep);
                    debug!("{player}'s Pokemon {in_play_idx} woke up");
                }
            }
        }

        // 4. Paralyzed: "After its owner's next turn, it recovers during Pokemon Checkup." So it
        //    clears only at a Checkup that ends its OWN owner's turn, and not at the one ending
        //    the turn it was inflicted on -- that turn is not yet "its owner's next turn". This
        //    covers both the ordinary case (inflicted on the opponent's turn, so the owner's
        //    whole next turn is denied) and a Paralysis applied during the owner's own turn,
        //    which survives the intervening opponent turn and denies the owner's turn after it.
        if checkup_targets.paralyzed.contains(&(player, in_play_idx)) && player == ending_player {
            if let Some(pokemon) = mutated_state.in_play_pokemon[player][in_play_idx].as_mut() {
                if pokemon.paralyzed_on_turn() == Some(ending_turn) {
                    debug!(
                        "{player}'s Pokemon {in_play_idx} was paralyzed this turn; it stays Paralyzed"
                    );
                } else {
                    pokemon.clear_status_condition(StatusCondition::Paralyzed);
                    debug!("{player}'s Pokemon {in_play_idx} is un-paralyzed");
                }
            }
        }
    }

    apply_checkup_healing_abilities(mutated_state);

    apply_snowy_terrain_checkup_damage(mutated_state);

    // Shift the per-turn KO flag. Turn advancement (including energy rotation) is performed
    // separately by `finish_turn_after_checkup` so it can consume the shared rng.
    mutated_state.knocked_out_by_opponent_attack_last_turn =
        mutated_state.knocked_out_by_opponent_attack_this_turn;
    mutated_state.knocked_out_by_opponent_attack_this_turn = false;
    mutated_state.knocked_out_types_last_turn =
        std::mem::take(&mut mutated_state.knocked_out_types_this_turn);
}

fn finish_turn_after_checkup(state: &mut State, rng: &mut StdRng) {
    state.advance_turn(rng);
}

/// Garganacl's Blessed Salt: "During Pokémon Checkup, heal `amount` damage from each of your
/// Pokémon." Applies once per in-play Pokémon with this ability (so it stacks if a player somehow
/// has more than one in play), healing every one of that ability's owner's in-play Pokémon
/// (Active and Benched).
fn apply_checkup_healing_abilities(state: &mut State) {
    let healers: Vec<(usize, u32)> = (0..2)
        .flat_map(|player| {
            state
                .enumerate_in_play_pokemon(player)
                .filter_map(move |(_, pokemon)| match pokemon.ability_mechanic() {
                    Some(AbilityMechanic::HealAllYourPokemonDuringCheckup { amount }) => {
                        Some((player, *amount))
                    }
                    _ => None,
                })
        })
        .collect();

    for (player, amount) in healers {
        debug!(
            "Blessed Salt: Healing {} damage from each of player {}'s Pokémon",
            amount, player
        );
        for pokemon in state.in_play_pokemon[player].iter_mut().flatten() {
            pokemon.heal(amount);
        }
    }
}

fn apply_snowy_terrain_checkup_damage(state: &mut State) {
    let mut active_only_damage: Vec<(usize, u32)> = vec![];
    let mut all_opponent_damage: Vec<(usize, u32)> = vec![];

    for (player, slots) in state.in_play_pokemon.iter().enumerate() {
        let Some(active) = slots[0].as_ref() else {
            continue;
        };
        if active.is_knocked_out() {
            continue;
        }
        match active.ability_mechanic() {
            Some(AbilityMechanic::CheckupDamageToOpponentActive { amount }) => {
                active_only_damage.push((player, *amount));
            }
            Some(AbilityMechanic::CheckupDamageToAllOpponentPokemon { amount }) => {
                all_opponent_damage.push((player, *amount));
            }
            _ => {}
        }
    }

    for (source_player, checkup_damage) in active_only_damage {
        let target_player = (source_player + 1) % 2;
        if state.in_play_pokemon[target_player][0].is_some() {
            debug!(
                "Snowy Terrain: Player {} active Pokémon deals {} checkup damage to opponent active",
                source_player, checkup_damage
            );
            handle_damage_only(
                state,
                (source_player, 0),
                &[(checkup_damage, target_player, 0)],
                false,
                DamageModifierContext::default(),
            );
        }
    }

    for (source_player, checkup_damage) in all_opponent_damage {
        let target_player = (source_player + 1) % 2;
        let targets: Vec<(u32, usize, usize)> = state
            .enumerate_in_play_pokemon(target_player)
            .map(|(idx, _)| (checkup_damage, target_player, idx))
            .collect();
        if !targets.is_empty() {
            debug!(
                "Sand Slammer: Player {} active Pokémon deals {} checkup damage to all opponent Pokémon",
                source_player, checkup_damage
            );
            handle_damage_only(
                state,
                (source_player, 0),
                &targets,
                false,
                DamageModifierContext::default(),
            );
        }
    }
}

fn generate_boolean_vectors(n: usize) -> Vec<Vec<bool>> {
    // The total number of combinations is 2^n
    let total_combinations = 1 << n; // 2^n

    // Generate all combinations
    (0..total_combinations)
        .map(|i| {
            // Convert the number `i` to its binary representation as a vector of booleans
            (0..n).map(|bit| (i & (1 << bit)) != 0).collect()
        })
        .collect()
}

fn checkapply_prevent_first_attack(
    state: &mut State,
    target_player: usize,
    target_pokemon_idx: usize,
    is_from_active_attack: bool,
) -> bool {
    if !is_from_active_attack {
        return false;
    }

    if let Some(target_pokemon) = state.in_play_pokemon[target_player][target_pokemon_idx].as_mut()
    {
        if !target_pokemon.prevent_first_attack_damage_used {
            if let Some(AbilityMechanic::PreventFirstAttack) = target_pokemon.ability_mechanic() {
                debug!("PreventFirstAttackDamageAfterEnteringPlay: Preventing first attack damage");
                target_pokemon.prevent_first_attack_damage_used = true;
                return true;
            }
        }
    }
    false
}

/// True if the Pokémon at `target` has the Guts ability and `raw_damage` (after modifiers)
/// would knock it out — i.e. it should flip a Guts survival coin for this damage.
fn guts_would_flip(
    state: &State,
    attacking_ref: (usize, usize),
    raw_damage: u32,
    target: (usize, usize),
    is_from_active_attack: bool,
    context: DamageModifierContext<'_>,
) -> bool {
    let has_guts = state.in_play_pokemon[target.0][target.1]
        .as_ref()
        .is_some_and(|pokemon| {
            matches!(
                pokemon.ability_mechanic(),
                Some(AbilityMechanic::CoinFlipToSurviveKnockOut)
            )
        });
    has_guts
        && damage_would_knock_out(
            state,
            attacking_ref,
            raw_damage,
            target,
            is_from_active_attack,
            context,
        )
}

/// True if `raw_damage` (after the usual modifiers) would knock out the Pokémon at `target`.
/// Forecast against the pre-attack board, so it is an estimate for effects that need to decide
/// "would this knock out?" before the damage is actually applied (Guts, Perish Body, Fade into
/// Darkness).
pub(crate) fn damage_would_knock_out(
    state: &State,
    attacking_ref: (usize, usize),
    raw_damage: u32,
    target: (usize, usize),
    is_from_active_attack: bool,
    context: DamageModifierContext<'_>,
) -> bool {
    if raw_damage == 0 {
        return false;
    }
    let Some(pokemon) = state.in_play_pokemon[target.0][target.1].as_ref() else {
        return false;
    };
    let modified = modify_damage(
        state,
        attacking_ref,
        (raw_damage, target.0, target.1),
        is_from_active_attack,
        context,
    );
    let remaining = pokemon.get_remaining_hp();
    remaining > 0 && modified >= remaining
}

/// Sum raw damage per (player, idx) target and return the targets that must flip a Guts
/// survival coin, sorted for deterministic branch ordering.
pub(crate) fn guts_flipping_targets(
    state: &State,
    attacking_ref: (usize, usize),
    targets: &[(u32, usize, usize)], // damage, target_player, in_play_idx
    is_from_active_attack: bool,
    context: DamageModifierContext<'_>,
) -> Vec<(usize, usize)> {
    // Sum raw damage per target (mirroring handle_damage_only) to find the Guts coin flips.
    let mut damage_map: HashMap<(usize, usize), u32> = HashMap::new();
    for (damage, player, idx) in targets {
        *damage_map.entry((*player, *idx)).or_insert(0) += damage;
    }
    let mut flipping: Vec<(usize, usize)> = damage_map
        .into_iter()
        .filter(|(target, raw_total)| {
            guts_would_flip(
                state,
                attacking_ref,
                *raw_total,
                *target,
                is_from_active_attack,
                context,
            )
        })
        .map(|(target, _)| target)
        .collect();
    flipping.sort_unstable();
    flipping
}

/// The damage a defender's coin-flip ability removes on heads: Carefree Steps prevents all of it
/// (`u32::MAX`), Securely Sheltered subtracts a fixed amount.
pub(crate) fn coin_flip_damage_reduction(pokemon: &PlayedCard) -> Option<u32> {
    pokemon
        .get_effective_card_effects()
        .iter()
        .find_map(|e| match e {
            CardEffect::CoinFlipToPreventIncomingDamage => Some(u32::MAX),
            CardEffect::CoinFlipToReduceIncomingDamage { amount } => Some(*amount),
            _ => None,
        })
}

/// The opponent Pokémon that flip a coin-flip damage ability for an `ApplyDamage`, paired with
/// their heads reduction. Only damage from an attack counts, and each Pokémon flips once however
/// many entries of `targets` hit it.
pub(crate) fn damage_prevention_flipping_targets(
    state: &State,
    attacking_player: usize,
    targets: &[(u32, usize, usize)], // damage, target_player, in_play_idx
    is_from_active_attack: bool,
) -> Vec<(usize, u32)> {
    if !is_from_active_attack {
        return vec![];
    }
    let opponent = (attacking_player + 1) % 2;
    let mut flipping: Vec<(usize, u32)> = vec![];
    for (damage, player, idx) in targets {
        if *damage == 0 || *player != opponent || flipping.iter().any(|(i, _)| i == idx) {
            continue;
        }
        let reduction = state.in_play_pokemon[opponent][*idx]
            .as_ref()
            .and_then(coin_flip_damage_reduction);
        if let Some(reduction) = reduction {
            flipping.push((*idx, reduction));
        }
    }
    flipping.sort_unstable();
    flipping
}

/// All `2^k` equally likely survivor subsets of `flipping` (`k = flipping.len()`), in mask
/// order (bit `i` of the mask set => `flipping[i]` survives its Guts coin flip).
pub(crate) fn enumerate_guts_survivor_subsets<T: Copy>(flipping: &[T]) -> Vec<Vec<T>> {
    let combos = 1usize << flipping.len();
    (0..combos)
        .map(|mask| {
            flipping
                .iter()
                .enumerate()
                .filter(|(bit, _)| (mask >> bit) & 1 == 1)
                .map(|(_, target)| *target)
                .collect()
        })
        .collect()
}

/// Set each Guts survivor's remaining HP to exactly 10. Must run after damage application
/// (so on-damage triggers like Rocky Helmet's counterattack fired) and before knockouts
/// are resolved.
pub(crate) fn set_guts_survivors_to_10(state: &mut State, survivors: &[(usize, usize)]) {
    for (player, idx) in survivors {
        if let Some(pokemon) = state.in_play_pokemon[*player][*idx].as_mut() {
            pokemon.set_remaining_hp(10);
        }
    }
}

/// This function applies damage (with modifiers and counterattacks) and handles K.O.s
/// and promotions.
pub(crate) fn handle_damage(
    state: &mut State,
    attacking_ref: (usize, usize), // (attacking_player, attacking_pokemon_idx)
    targets: &[(u32, usize, usize)], // damage, target_player, in_play_idx
    is_from_active_attack: bool,
    attack_name: Option<&str>,
) {
    handle_damage_only(
        state,
        attacking_ref,
        targets,
        is_from_active_attack,
        DamageModifierContext {
            attack_name,
            attack_effect: None,
        },
    );
    handle_knockouts(state, attacking_ref, is_from_active_attack);
}

// This function handles Counter-Attacks and Attack Modifiers, but doesn't handle K.O.s or
// queues up promotion decisions. Use carefully, probably just in a few places
pub(crate) fn handle_damage_only(
    state: &mut State,
    attacking_ref: (usize, usize), // (attacking_player, attacking_pokemon_idx)
    targets: &[(u32, usize, usize)], // damage, target_player, in_play_idx
    is_from_active_attack: bool,
    context: DamageModifierContext<'_>,
) {
    let attacking_player = attacking_ref.0;

    // Reduce and sum damage for duplicate targets
    let mut damage_map: HashMap<(usize, usize), u32> = HashMap::new();
    for (damage, player, idx) in targets {
        *damage_map.entry((*player, *idx)).or_insert(0) += damage;
    }
    let targets: Vec<(u32, usize, usize)> = damage_map
        .into_iter()
        .map(|((player, idx), damage)| (damage, player, idx))
        .collect();

    // Modify to apply any multipliers (e.g. Oricorio, Giovanni, etc...)
    let modified_targets = targets
        .iter()
        .map(|target_ref| {
            let modified_damage = modify_damage(
                state,
                attacking_ref,
                *target_ref,
                is_from_active_attack,
                context,
            );
            (modified_damage, target_ref.1, target_ref.2)
        })
        .collect::<Vec<(u32, usize, usize)>>();

    // Handle each target individually
    for (damage, target_player, target_pokemon_idx) in modified_targets {
        // 0 damage is not damage, so it must not use up a "first damaged" Disguise
        if damage == 0 {
            continue;
        }
        let applied = checkapply_prevent_first_attack(
            state,
            target_player,
            target_pokemon_idx,
            is_from_active_attack,
        );
        if applied {
            continue;
        }

        // Apply damage
        {
            let target_pokemon = state.in_play_pokemon[target_player][target_pokemon_idx]
                .as_mut()
                .expect("Pokemon should be there if taking damage");
            target_pokemon.apply_damage(damage); // Applies without surpassing 0 HP
            if is_from_active_attack && target_pokemon_idx == 0 {
                target_pokemon.mark_damaged_by_attack_while_active();
            }
            debug!(
                "Dealt {} damage to opponent's {} Pokemon. Remaining HP: {}",
                damage,
                target_pokemon_idx,
                target_pokemon.get_remaining_hp()
            );
        }

        // Consider Counter-Attack (only if from Active Attack to Active)
        if !(is_from_active_attack && target_pokemon_idx == 0) {
            continue;
        }

        let target_pokemon = state.in_play_pokemon[target_player][target_pokemon_idx]
            .as_ref()
            .expect("Pokemon should be there if taking damage");
        let counter_damage = {
            if target_pokemon_idx == 0 {
                get_counterattack_damage(target_pokemon)
            } else {
                0
            }
        };
        let delayed_counter_damage = get_delayed_counterattack_damage(target_pokemon);
        let should_poison = should_poison_attacker(target_pokemon);
        // "If this Pokémon is in the Active Spot and is Knocked Out by damage from an attack from
        // your opponent's Pokémon, do X damage to ..." (Pyukumuku's Innards Out, Team Rocket's
        // Electrode's Destiny Burst, Spiritomb's Final Scream). Resolved here alongside the
        // ordinary counterattack recoil so that the retaliation damage is picked up by the
        // `handle_knockouts` pass that follows this call — exactly like Rocky Helmet's.
        let knockout_retaliation = (attacking_player != target_player
            && target_pokemon.is_knocked_out())
        .then(|| target_pokemon.ability_mechanic())
        .flatten();

        // Apply counterattack damage and poison
        if counter_damage > 0 {
            // The hit back an attack left (Cursed Jewel, Spike Armor, ...) is part of that
            // attack, so it takes Weakness. Rocky Helmet's and Abilities' damage stays flat.
            let hit_back_weakness_extra = if delayed_counter_damage > 0 {
                let attacking_pokemon = state.in_play_pokemon[attacking_player][0]
                    .as_ref()
                    .expect("Active Pokemon should be there");
                get_attack_hit_back_weakness_extra(
                    state,
                    target_pokemon,
                    attacking_pokemon,
                    delayed_counter_damage,
                )
            } else {
                0
            };
            let attacking_pokemon = state.in_play_pokemon[attacking_player][0]
                .as_mut()
                .expect("Active Pokemon should be there");
            attacking_pokemon.apply_damage(counter_damage + hit_back_weakness_extra);
            debug!(
                "Dealt {} counterattack damage to active Pokemon. Remaining HP: {}",
                counter_damage + hit_back_weakness_extra,
                attacking_pokemon.get_remaining_hp()
            );

            // The attacking Pokemon was itself just damaged by the defender's delayed counterattack
            // (e.g. Mega Sableye ex's Cursed Jewel). If it's holding its own Rocky Helmet, that
            // hit reflects 20 damage back onto the original defender too. Rocky Helmet's own
            // recoil does not count, so two helmets don't ping-pong.
            let attacking_pokemon = state.in_play_pokemon[attacking_player][0]
                .as_ref()
                .expect("Active Pokemon should be there");
            if delayed_counter_damage > 0 && has_tool(attacking_pokemon, CardId::A2148RockyHelmet) {
                let target_pokemon = state.in_play_pokemon[target_player][target_pokemon_idx]
                    .as_mut()
                    .expect("Pokemon should be there if taking damage");
                target_pokemon.apply_damage(20);
                debug!(
                    "Rocky Helmet reflects 20 damage back to the original defender. Remaining HP: {}",
                    target_pokemon.get_remaining_hp()
                );
            }
        }

        match knockout_retaliation {
            Some(AbilityMechanic::DamageAttackerOnKnockout { amount }) => {
                if let Some(attacking_pokemon) = state.in_play_pokemon[attacking_player][0].as_mut()
                {
                    debug!(
                        "Knockout retaliation: dealing {amount} damage to the Attacking Pokemon"
                    );
                    attacking_pokemon.apply_damage(*amount);
                }
            }
            Some(AbilityMechanic::DamageEachOpponentPokemonOnKnockout { amount }) => {
                debug!(
                    "Knockout retaliation: dealing {amount} damage to each of the attacker's Pokemon"
                );
                for pokemon in state.in_play_pokemon[attacking_player].iter_mut().flatten() {
                    pokemon.apply_damage(*amount);
                }
            }
            _ => {}
        }

        if should_poison {
            state.apply_status_condition(attacking_player, 0, StatusCondition::Poisoned);
            debug!("Poison Barb: Poisoned the attacking Pokemon");
        }

        if attacking_player != target_player {
            apply_bouncy_body(state, target_player);
            apply_dark_pendant_trigger(state, attacking_player, target_player);
        }
    }
}

/// Dark Pendant: "If the [D] Pokémon this card is attached to is in the Active Spot and is damaged
/// by an attack from your opponent's Pokémon, your opponent reveals a random card from their hand
/// and shuffles it into their deck."
///
/// The shuffle needs the shared RNG, which the damage path does not carry, so it is queued as the
/// single option on the attacker's move-generation stack (the same trick Bouncy Body uses for its
/// choice). With one option it is not a decision — it just resolves where an RNG is available.
fn apply_dark_pendant_trigger(state: &mut State, attacking_player: usize, target_player: usize) {
    let Some(defender) = state.in_play_pokemon[target_player][0].as_ref() else {
        return;
    };
    if !has_tool(defender, CardId::A4154DarkPendant)
        || !defender.is_type(crate::models::EnergyType::Darkness)
        || state.hands[attacking_player].is_empty()
    {
        return;
    }
    debug!("Dark Pendant: Attacker shuffles a random card from their hand into their deck");
    state.move_generation_stack.push((
        attacking_player,
        vec![SimpleAction::ShuffleRandomOwnHandCardIntoDeck],
    ));
}

/// Jellicent's Bouncy Body: the Active Pokémon was just damaged by an attack from the opponent's
/// Pokémon, so its owner takes an Energy from their Energy Zone and attaches it to 1 of their
/// Benched Pokémon (their choice).
///
/// Queued before knockouts resolve, so the choice is offered while the Bench is still intact
/// (promotions are inserted at the bottom of the stack and therefore resolve afterwards).
fn apply_bouncy_body(state: &mut State, target_player: usize) {
    let Some(AbilityMechanic::AttachEnergyFromZoneToBenchedOnDamaged { energy_type }) = state
        .in_play_pokemon[target_player][0]
        .as_ref()
        .and_then(|active| active.ability_mechanic())
    else {
        return;
    };

    let choices = state
        .enumerate_bench_pokemon(target_player)
        .map(|(in_play_idx, _)| SimpleAction::Attach {
            attachments: vec![(1, *energy_type, in_play_idx)],
            is_turn_energy: false,
        })
        .collect::<Vec<_>>();
    if choices.is_empty() {
        return; // Nowhere to put the Energy.
    }

    debug!("Bouncy Body: Attaching a {energy_type:?} Energy to a Benched Pokemon");
    state.move_generation_stack.push((target_player, choices));
}

fn is_iris_bonus_active(
    state: &State,
    attacking_ref: (usize, usize),
    is_from_active_attack: bool,
) -> bool {
    if !is_from_active_attack {
        return false;
    }
    let has_iris_effect = state
        .get_current_turn_effects()
        .iter()
        .any(|e| matches!(e, TurnEffect::BonusPointForHaxorusActiveKO));
    if !has_iris_effect {
        return false;
    }
    state.in_play_pokemon[attacking_ref.0][attacking_ref.1]
        .as_ref()
        .map(|attacker| {
            matches!(
                CardId::from_card_id(match &attacker.card {
                    Card::Pokemon(p) => p.id.as_str(),
                    Card::Trainer(t) => t.id.as_str(),
                }),
                Some(CardId::B2b056Haxorus | CardId::B2b110Haxorus | CardId::PB045Haxorus)
            )
        })
        .unwrap_or(false)
}

pub(crate) fn handle_knockouts(
    state: &mut State,
    attacking_ref: (usize, usize), // (attacking_player, attacking_pokemon_idx)
    is_from_active_attack: bool,
) {
    // Hala: "During your opponent's next turn, if your Hariyama or Crabominable would be Knocked
    // Out by damage from an attack, it is not Knocked Out and its remaining HP becomes 10."
    // Applied before the KO list is taken, so a protected Pokémon never enters it.
    apply_survive_knockout_turn_effects(state, is_from_active_attack);

    let knockouts = get_knocked_out(state);
    let iris_bonus_active = is_iris_bonus_active(state, attacking_ref, is_from_active_attack);

    // Handle knockouts: Discard cards and award points (to potentially short-circuit promotions)
    for (ko_receiver, ko_pokemon_idx) in knockouts.clone() {
        // Call knockout hook (e.g., for Electrical Cord)
        on_knockout(
            state,
            ko_receiver,
            ko_pokemon_idx,
            attacking_ref,
            is_from_active_attack,
        );
        on_attack_knockout(state, attacking_ref, ko_receiver, is_from_active_attack);

        // Award points
        {
            let ko_pokemon = state.in_play_pokemon[ko_receiver][ko_pokemon_idx]
                .as_ref()
                .expect("Pokemon should be there if knocked out");
            let ko_initiator = (ko_receiver + 1) % 2;
            // Dusknoir's Fade into Darkness / Glimmora's Shattering Crystal: on a heads flip the
            // opponent gets no points at all for this Knock Out.
            let points_won = if ko_pokemon.knockout_points_denied {
                0
            } else {
                ko_pokemon.card.get_knockout_points()
            };
            state.points[ko_initiator] += points_won;
            debug!(
                "Pokemon {:?} fainted. Player {} won {} points for a total of {}",
                ko_pokemon, ko_initiator, points_won, state.points[ko_initiator]
            );
            // Iris bonus: 1 extra point if Haxorus KOs opponent's Active Pokemon
            if iris_bonus_active
                && points_won > 0
                && ko_pokemon_idx == 0
                && ko_receiver != attacking_ref.0
            {
                state.points[ko_initiator] += 1;
                debug!(
                    "Iris: Player {} gets 1 bonus point for Haxorus KO",
                    ko_initiator
                );
            }
        }

        // Record KOs dealt by an opponent's active attack (for revenge attacks such as
        // Marshadow's Revenge and Zarude's Dark Vengeance), along with the KO'd Pokemon's type.
        if is_from_active_attack && ko_receiver != attacking_ref.0 {
            // Record *every* type the KO'd Pokemon counted as in play, so a type-restricted
            // revenge attack sees a dual-type Pokemon under either of its types.
            let ko_pokemon_types = state.in_play_pokemon[ko_receiver][ko_pokemon_idx]
                .as_ref()
                .map(|pokemon| pokemon.get_energy_types())
                .unwrap_or_default();
            state.record_knocked_out_by_opponent_attack(&ko_pokemon_types);
        }

        // Every knockout counts against the player who lost the Pokemon, however it happened
        // (Kingambit's Overlord's Blade counts self-inflicted and Checkup knockouts too).
        state.record_own_knockout(ko_receiver);

        // Rescue Scarf: "If the Pokémon this card is attached to is Knocked Out by damage from an
        // attack from your opponent's Pokémon, put it into your hand instead of the discard pile."
        let rescued = is_from_active_attack
            && ko_receiver != attacking_ref.0
            && state.in_play_pokemon[ko_receiver][ko_pokemon_idx]
                .as_ref()
                .is_some_and(|pokemon| has_tool(pokemon, CardId::A4155RescueScarf));
        if rescued {
            debug!("Rescue Scarf: Returning the Knocked Out Pokemon to its owner's hand");
            state.return_from_play_to_hand(ko_receiver, ko_pokemon_idx);
        } else {
            state.discard_from_play(ko_receiver, ko_pokemon_idx);
        }
    }

    // Losing an HP aura can knock out a Benched Pokemon after an earlier
    // knockout already queued promotion choices. Never offer a now-empty slot:
    // activating it would leave the Active Spot empty after the stack resolves.
    // The same goes for an offered Ability: a Basic kept alive only by Starting Plains
    // loses the bonus when it evolves, so the evolution can be knocked out with its
    // on-evolve offer still on the stack. The offer's Noop stays: on a Victory Star
    // offer, it is what resolves the pending attack.
    let occupied = state
        .in_play_pokemon
        .each_ref()
        .map(|board| board.each_ref().map(Option::is_some));
    for (actor, choices) in &mut state.move_generation_stack {
        let actor = *actor;
        choices.retain(|choice| match choice {
            SimpleAction::Activate {
                player,
                in_play_idx,
            } => occupied[*player][*in_play_idx],
            SimpleAction::UseAbility { in_play_idx } => occupied[actor][*in_play_idx],
            _ => true,
        });
    }
    // If game ends because of knockouts, set winner and return so as to short-circuit promotion logic
    // Note even attacking player can lose by counterattack K.O.
    if state.points[0] >= 3 && state.points[1] >= 3 {
        // Both players reached the target on the same action. In-app Tips: "If a player doesn't
        // have any Pokemon remaining in play, that player loses the battle regardless of the
        // number of points each player has." So an empty board still loses here -- a
        // simultaneous point win does not rescue it into a tie. It is only a tie when the
        // no-Pokemon rule cannot separate the players: either both still have Pokemon, or
        // neither does.
        let p0_has_pokemon = state.enumerate_in_play_pokemon(0).next().is_some();
        let p1_has_pokemon = state.enumerate_in_play_pokemon(1).next().is_some();
        state.winner = Some(match (p0_has_pokemon, p1_has_pokemon) {
            (false, true) => {
                debug!("Both players have 3 points, but player 0 has no Pokemon left and loses");
                GameOutcome::Win(1)
            }
            (true, false) => {
                debug!("Both players have 3 points, but player 1 has no Pokemon left and loses");
                GameOutcome::Win(0)
            }
            _ => {
                debug!("Both players have 3 points, it's a tie");
                GameOutcome::Tie
            }
        });
        return;
    } else if state.points[0] >= 3 {
        state.winner = Some(GameOutcome::Win(0));
        return;
    } else if state.points[1] >= 3 {
        state.winner = Some(GameOutcome::Win(1));
        return;
    }

    // If a player has no Pokemon left in play, they immediately lose (even if points < 3)
    let p0_remaining = state.enumerate_in_play_pokemon(0).count();
    let p1_remaining = state.enumerate_in_play_pokemon(1).count();
    if p0_remaining == 0 && p1_remaining == 0 {
        debug!("Both players have no Pokemon left in play, it's a tie");
        state.winner = Some(GameOutcome::Tie);
        return;
    } else if p0_remaining == 0 {
        state.winner = Some(GameOutcome::Win(1));
        return;
    } else if p1_remaining == 0 {
        state.winner = Some(GameOutcome::Win(0));
        return;
    }

    // Queue up promotion actions if the game is still on after a knockout. After a double Knock
    // Out from an attack, the attacking (turn) player promotes first, whichever seat that is.
    // `sort_by_key` is stable, and `get_knocked_out` lists seat 0 first, so every other order
    // (Checkup, Abilities) is unchanged.
    let mut knockouts = knockouts;
    if is_from_active_attack {
        knockouts.sort_by_key(|(ko_receiver, _)| *ko_receiver != attacking_ref.0);
    }
    for (ko_receiver, ko_pokemon_idx) in knockouts {
        if ko_pokemon_idx != 0 {
            continue; // Only promote if K.O. was on Active
        }
        // If K.O. was Active, trigger promotion or declare winner
        state.trigger_promotion_or_declare_winner(ko_receiver);
    }
}

/// Hala-style protection: any Pokémon that would be Knocked Out by attack damage and is covered by
/// a `SurviveKnockOutForSpecificPokemon` turn effect survives instead, at a fixed remaining HP.
/// Only attack damage qualifies, so poison/burn/self-inflicted knockouts still resolve normally.
fn apply_survive_knockout_turn_effects(state: &mut State, is_from_active_attack: bool) {
    if !is_from_active_attack {
        return;
    }
    let protections: Vec<(usize, Vec<String>, u32)> = state
        .get_current_turn_effects()
        .into_iter()
        .filter_map(|effect| match effect {
            TurnEffect::SurviveKnockOutForSpecificPokemon {
                pokemon_names,
                player,
                remaining_hp,
            } => Some((player, pokemon_names, remaining_hp)),
            _ => None,
        })
        .collect();
    if protections.is_empty() {
        return;
    }

    for (player, pokemon_names, remaining_hp) in protections {
        for pokemon in state.in_play_pokemon[player].iter_mut().flatten() {
            if pokemon.is_knocked_out() && pokemon_names.contains(&pokemon.get_name()) {
                debug!(
                    "Survive Knock Out: {} survives with {} HP",
                    pokemon.get_name(),
                    remaining_hp
                );
                pokemon.set_remaining_hp(remaining_hp);
            }
        }
    }
}

fn get_knocked_out(state: &State) -> Vec<(usize, usize)> {
    let mut knockouts: Vec<(usize, usize)> = vec![];
    for (idx, card) in state.enumerate_in_play_pokemon(0) {
        if card.is_knocked_out() {
            knockouts.push((0, idx));
        }
    }
    for (idx, card) in state.enumerate_in_play_pokemon(1) {
        if card.is_knocked_out() {
            knockouts.push((1, idx));
        }
    }
    knockouts
}

/// Shuffle `player`'s Pokémon at `in_play_idx`, and everything attached to it, back into their
/// deck: the card itself, every card it evolved from, and any attached Tool all go into the deck
/// (which is then shuffled), while attached Energy returns to the discarded-Energy pile.
///
/// This is the "and all attached cards" form used by attacks like Eldegoss's Float Up and
/// Accelgor's Deck and Cover. It differs from `apply_shuffle_in_play_pokemon_into_deck` (Professor
/// Turo), which returns only the Pokémon cards and leaves the Tool and Energy behind.
pub(crate) fn shuffle_in_play_pokemon_and_attachments_into_deck(
    rng: &mut StdRng,
    state: &mut State,
    player: usize,
    in_play_idx: usize,
) {
    let Some(pokemon) = state.in_play_pokemon[player][in_play_idx].take() else {
        return;
    };

    let mut cards_to_shuffle = pokemon.cards_behind.clone();
    cards_to_shuffle.push(pokemon.card.clone());
    cards_to_shuffle.extend(pokemon.attached_tools.iter().cloned());
    state.decks[player].cards.extend(cards_to_shuffle);
    state.discard_energies[player].extend(pokemon.attached_energy.iter().cloned());
    state.decks[player].shuffle(false, rng);
    state.refresh_double_grass_bonus_for_player(player);

    if in_play_idx == 0 {
        state.trigger_promotion_or_declare_winner(player);
    }
}

/// Swap a bench pokemon into the active spot, clearing status/effects and setting turn flags.
/// This is the swap portion of retreat without energy payment.
pub(crate) fn apply_activate(player: usize, state: &mut State, bench_idx: usize) {
    state.in_play_pokemon[player].swap(0, bench_idx);

    if let Some(pokemon) = state.in_play_pokemon[player][bench_idx].as_mut() {
        pokemon.clear_status_and_effects();
    }

    if let Some(pokemon) = state.in_play_pokemon[player][0].as_mut() {
        pokemon.moved_to_active_this_turn = true;
    }
}

// Apply common logic in outcomes
pub(crate) fn wrap_with_common_logic(mutation: Mutation) -> Mutation {
    Box::new(move |rng, state, action| {
        // Counted here so played games and search simulations count the same actions.
        state.actions_this_turn = state.actions_this_turn.saturating_add(1);
        if action.is_stack {
            state.move_generation_stack.pop();
        }
        if let SimpleAction::Play { trainer_card } = &action.action {
            let card = Card::Trainer(trainer_card.clone());
            if trainer_card.trainer_card_type == TrainerType::Stadium {
                state.has_played_stadium = true;
                // Replaced Stadium cards go to the discard pile of the player who played them.
                if let Some((old_stadium, old_owner)) =
                    state.set_active_stadium_for_player(action.actor, card.clone())
                {
                    state.discard_piles[old_owner.unwrap_or(action.actor)].push(old_stadium);
                }
                state.remove_card_from_hand(action.actor, &card);
                state.refresh_starting_plains_bonus_all();
                handle_knockouts(state, (action.actor, 0), false);
            } else if trainer_card.trainer_card_type == TrainerType::Tool {
                state.remove_card_from_hand(action.actor, &card);
            } else {
                state.discard_card_from_hand(action.actor, &card);
            }
            if card.is_support() {
                state.has_played_support = true;
            }
        }
        if let SimpleAction::UseAbility { in_play_idx } = &action.action {
            let pokemon = state.in_play_pokemon[action.actor][*in_play_idx]
                .as_mut()
                .expect("Pokemon should be there if using ability");
            pokemon.ability_used = true;
        }
        if let SimpleAction::Attack(attack) = &action.action {
            state.record_attack_used(action.actor, attack.title.clone());
        }

        mutation(rng, state, action); // in the case of attacks, have this be damage + effect.

        // Catch-all knockout check: any action could have reduced a Pokemon's
        // effective HP below its damage taken (e.g. Field Blower discarding a
        // Giant Cape). This way individual mutations don't need to remember to
        // check for knockouts themselves. Damage-dealing mutations already call
        // handle_knockouts with the proper attacking context, so this is a no-op
        // for them.
        // Skipped during the initial setup phase, where players place their boards
        // one at a time and "0 Pokemon in play" doesn't mean a loss.
        if state.turn_count > 0 {
            handle_knockouts(state, (action.actor, 0), false);
        }

        if let SimpleAction::Attack(_) = &action.action {
            // We use a flag instead of .move_generation_stack to reduce
            // stack surgery to make sure things happen in order.
            // This ensures move_generation_stack (effects and promotions)
            // has priority over ending the turn.
            state.end_turn_pending = true;
        }
    })
}

fn noop_mutation() -> Mutation {
    Box::new(|_, _, _| {})
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{card_ids::CardId, database::get_card_by_enum, hooks::to_playable_card};
    use rand::SeedableRng;

    #[test]
    fn test_poison_damage_no_nihilego() {
        let state = State::default();
        // Poison damage should be 10 with no Nihilego in play
        assert_eq!(get_poison_damage(&state, 0, 0), 10);
    }

    #[test]
    fn test_poison_damage_with_nihilego() {
        let mut state = State::default();

        // Add 2 Nihilego to opponent's field (player 1)
        let nihilego = get_card_by_enum(CardId::A3a042Nihilego);
        state.in_play_pokemon[1][0] = Some(to_playable_card(&nihilego, false));
        state.in_play_pokemon[1][1] = Some(to_playable_card(&nihilego, false));

        // Player 0's active pokemon should take 30 damage (10 base + 10 per Nihilego)
        assert_eq!(get_poison_damage(&state, 0, 0), 30);
    }

    #[test]
    fn test_mimikyu_ex_disguise_prevents_first_attack_only() {
        let mut state = State::default();

        let attacker = get_card_by_enum(CardId::A1001Bulbasaur);
        let mimikyu_ex = get_card_by_enum(CardId::B2073MimikyuEx);

        state.in_play_pokemon[0][0] = Some(to_playable_card(&attacker, false));
        state.in_play_pokemon[1][0] = Some(to_playable_card(&mimikyu_ex, false));

        let starting_hp = state.get_active(1).get_remaining_hp();

        // First attack damage should be prevented
        handle_damage(&mut state, (0, 0), &[(30, 1, 0)], true, None);
        assert_eq!(state.get_active(1).get_remaining_hp(), starting_hp);

        // Second attack should deal damage normally
        handle_damage(&mut state, (0, 0), &[(30, 1, 0)], true, None);
        assert_eq!(state.get_active(1).get_remaining_hp(), starting_hp - 30);
    }

    /// Player 0's Mankey is Asleep, with `num_coins` Checkup coins from Soothing Lullaby or an
    /// ordinary Sleep for `None`; a Bulbasaur waits on its Bench.
    fn mankey_asleep(num_coins: Option<usize>) -> State {
        let game = crate::test_support::get_test_game_with_board(
            vec![
                PlayedCard::from_id(CardId::PA017Mankey),
                PlayedCard::from_id(CardId::A1001Bulbasaur),
            ],
            vec![PlayedCard::from_id(CardId::A1001Bulbasaur)],
        );
        let mut state = game.get_state_clone();
        match num_coins {
            Some(num_coins) => state.apply_sleep_with_coins(0, 0, num_coins),
            None => state.apply_status_condition(0, 0, StatusCondition::Asleep),
        }
        assert!(state.get_active(0).is_asleep());
        state
    }

    /// The chance that player 0's Active is awake after the Checkup that ends player 0's turn.
    fn chance_to_wake_at_checkup(state: &State) -> f64 {
        let action = Action {
            actor: 0,
            action: SimpleAction::EndTurn,
            is_stack: false,
        };
        let (probabilities, mutations) = forecast_pokemon_checkup(state);
        let mut chance = 0.0;
        for (probability, mutation) in probabilities.into_iter().zip(mutations) {
            let mut after = state.clone();
            mutation(&mut StdRng::seed_from_u64(0), &mut after, &action);
            if !after.get_active(0).is_asleep() {
                chance += probability;
            }
        }
        chance
    }

    #[test]
    fn test_ordinary_sleep_wakes_on_one_head() {
        assert_eq!(chance_to_wake_at_checkup(&mankey_asleep(None)), 0.5);
    }

    #[test]
    fn test_soothing_lullaby_sleep_wakes_only_on_two_heads() {
        assert_eq!(chance_to_wake_at_checkup(&mankey_asleep(Some(2))), 0.25);
    }

    #[test]
    fn test_sleep_coins_are_flipped_separately_for_each_sleeper_and_burn() {
        // Soothing Lullaby's Mankey (2 coins), an ordinary Sleep on the other player's Bulbasaur
        // (1 coin), and that Bulbasaur's Burn (1 coin) need 4 coins; each is independent.
        let mut state = mankey_asleep(Some(2));
        state.apply_status_condition(1, 0, StatusCondition::Asleep);
        state.apply_status_condition(1, 0, StatusCondition::Burned);
        let targets = collect_checkup_targets(&state);
        assert_eq!(targets.total_sleep_coins(), 3);
        assert_eq!(chance_to_wake_at_checkup(&state), 0.25);
        let (probabilities, _) = forecast_pokemon_checkup(&state);
        assert_eq!(probabilities, vec![1.0 / 16.0; 16]);
    }

    #[test]
    fn test_soothing_lullaby_sleep_ends_when_the_pokemon_goes_to_the_bench() {
        let mut state = mankey_asleep(Some(2));
        apply_activate(0, &mut state, 1);
        let benched = state.in_play_pokemon[0][1].as_ref().unwrap();
        assert!(!benched.is_asleep());
        assert_eq!(benched.sleep_checkup_coins(), 1);

        // Back in the Active Spot, a later ordinary Sleep flips 1 coin.
        apply_activate(0, &mut state, 1);
        state.apply_status_condition(0, 0, StatusCondition::Asleep);
        assert_eq!(state.get_active(0).sleep_checkup_coins(), 1);
    }

    #[test]
    fn test_soothing_lullaby_sleep_ends_when_the_pokemon_evolves() {
        let mut state = mankey_asleep(Some(2));
        let primeape = get_card_by_enum(CardId::A1142Primeape);
        state.hands[0] = vec![primeape.clone()];
        crate::actions::apply_evolve(0, &mut state, &primeape, 0, false);
        assert!(!state.get_active(0).is_asleep());
        assert_eq!(state.get_active(0).sleep_checkup_coins(), 1);
    }

    #[test]
    fn test_soothing_lullaby_sleep_ends_when_the_pokemon_recovers() {
        // Full Heal and the like cure every Special Condition; a Checkup wake-up and a
        // Paralysis replacing the Sleep clear only the Sleep.
        let mut cured = mankey_asleep(Some(2));
        cured.in_play_pokemon[0][0]
            .as_mut()
            .unwrap()
            .cure_status_conditions();
        let mut paralyzed = mankey_asleep(Some(2));
        paralyzed.apply_status_condition(0, 0, StatusCondition::Paralyzed);
        let mut woke = mankey_asleep(Some(2));
        woke.in_play_pokemon[0][0]
            .as_mut()
            .unwrap()
            .clear_status_condition(StatusCondition::Asleep);

        for mut state in [cured, paralyzed, woke] {
            assert!(!state.get_active(0).is_asleep());
            state.apply_status_condition(0, 0, StatusCondition::Asleep);
            assert_eq!(state.get_active(0).sleep_checkup_coins(), 1);
        }
    }

    #[test]
    fn test_an_ordinary_sleep_replaces_soothing_lullabys() {
        let mut state = mankey_asleep(Some(2));
        state.apply_status_condition(0, 0, StatusCondition::Asleep);
        assert_eq!(state.get_active(0).sleep_checkup_coins(), 1);
    }
}
